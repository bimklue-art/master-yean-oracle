# MASTER YEAN ORACLE — Release QA Checklist

## Loading
- [ ] Loading screen reaches 34 / 34
- [ ] No card image remains blank
- [ ] Opening screen fades in correctly

## Opening ceremony
- [ ] Opening title is centered
- [ ] Start button responds once only
- [ ] Entry transition completes smoothly
- [ ] No double-click issue occurs

## Drawing ritual
- [ ] Heaven begins active
- [ ] Earth remains locked until Heaven is drawn
- [ ] Human remains locked until Earth is drawn
- [ ] Each card flips correctly
- [ ] Artwork fills the card frame
- [ ] Draw sounds are balanced
- [ ] Mute control works

## Completion
- [ ] Human card remains visible long enough
- [ ] Transition ceremony appears
- [ ] Final spread shows the correct three cards
- [ ] Cards do not overlap
- [ ] Restart begins a fresh reading
- [ ] End ceremony returns to opening screen

## Mobile
- [ ] No horizontal scrolling
- [ ] Cards fit phone width
- [ ] Buttons are easy to tap
- [ ] Final spread fits the screen
- [ ] Sound button does not cover important content

## Reliability
- [ ] Refreshing the page works
- [ ] Sound preference is remembered
- [ ] Browser console shows no errors
- [ ] Production build succeeds
- [ ] Error recovery screen displays when tested

## Release
- [ ] Git repository is clean
- [ ] All 34 images are committed
- [ ] `npm run build` succeeds
- [ ] Public deployment tested
- [ ] Release tag created
