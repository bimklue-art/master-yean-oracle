# MASTER YEAN ORACLE — Deployment Guide

## 1. Final local test

Run:

```bash
npm install
npm run dev
```

Complete one full ritual and verify:

- Opening ceremony appears
- Start button works
- Heaven, Earth, and Human draw in order
- Third-card pause is visible
- Transition ceremony appears
- Result spread displays all three card images
- Sound toggle works
- Sound preference survives refresh
- Restart and end ceremony buttons work
- Mobile layout works in Chrome DevTools
- No browser console errors appear

## 2. Production build test

Run:

```bash
npm run build
npm run preview
```

Open the preview URL and repeat the full ritual.

The production build must complete without errors before deployment.

## 3. Vercel deployment

1. Push the project to GitHub.
2. Sign in to Vercel.
3. Select **Add New Project**.
4. Import the GitHub repository.
5. Confirm:
   - Framework preset: Vite
   - Build command: `npm run build`
   - Output directory: `dist`
6. Deploy.

Keep `vercel.json` in the project root.

## 4. Netlify deployment

1. Push the project to GitHub.
2. Sign in to Netlify.
3. Choose **Add new site** → **Import an existing project**.
4. Select the repository.
5. Confirm:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Deploy.

Keep `netlify.toml` in the project root.

## 5. Recommended release tag

After successful deployment:

```bash
git add .
git commit -m "Release MASTER YEAN ORACLE v1.0.0"
git tag v1.0.0
git push origin main
git push origin v1.0.0
```

## 6. Suggested browser testing

Test at minimum:

- Google Chrome desktop
- Microsoft Edge desktop
- Chrome Android
- Safari iPhone
- Safari iPad

## 7. Important asset check

All files inside `src/assets/cards` must remain tracked in Git.

Before pushing, run:

```bash
git status
```

Confirm no oracle card images are missing or untracked.

## 8. Recommended first release status

Use the first online deployment as a release candidate:

```text
v1.0.0-rc1
```

After testing the public link on desktop and mobile, promote it to:

```text
v1.0.0
```
